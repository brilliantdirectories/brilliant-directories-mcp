# METHODOLOGY: BD growth-skills protocol

Read first. Every `/bd:*` skill follows this. The content-type file (`content-types/<type>.md`, routed to by `SKILL.md`) layers in type-specific details.

## Autonomy

Runs are autonomous: no user can reply mid-run — never ask; a question ends the run as a failure. Decide per this skill with safer-side defaults and proceed to the receipt.

**A wrong fact is worse than a missing fact — a rule that weighs facts, never length. When a fact is in doubt, skip it and move to the next — doubt about a detail never ends the run. A doubtful candidate is settled by its gates and verdicts, never by leaving it uncounted — every qualifying result probes.**

**The linking pass matches the draft's own phrases to the inventory: every phrase that exists in the draft with a verified internal target takes its link — never a phrase invented or a sentence bent to spend a target, only the phrases the draft already holds. A phrase left unlinked while its target stands is the miss.**

## Stage 1: Site context

Build the agent's mental model of the site — what it's about, who it serves, its taxonomy, its main navigation — for vertical alignment. **Turn 1 starts exactly here: fire these 6 calls as the run's opening batched round, before anything else.** The 4 site-context calls (`getSiteInfo`, `listTopCategories`, `listPostTypes`, `listMenuItems`) are independent and fully specified here — they need no `getToolSchema`. The 5th and 6th are the two schemas the run lives on: `getToolSchema createSingleImagePost` and `getToolSchema listSingleImagePosts` — each fired once, alongside the 4 site-context calls; turn 1's slots are exactly these. Then process results. Numbering is read order, not turn order.

1. `getSiteInfo` → industry, profession, primary_country, language, timezone (IANA identifier, e.g. `America/Los_Angeles`), `current_site_datetime` (site-local now, `YYYYMMDDHHmmss`), brand, directory landing URL. Bank the landing URL into the internal-link inventory as a Pattern 5 candidate.
2. `listTopCategories limit=25` → **sample only, for site-flavor signal.** These are the categories actual site members are assigned to (e.g. "Personal Training", "Group Fitness") — NOT post-type categories. Real sites can have 100s of rows; 25 is enough to read the vertical. Do NOT use these for post category routing — post categories come from the resolved post type's `feature_categories` field (step 3).
3. `listPostTypes` → the content-type file provides its marker (e.g. events `type_of_feature=1`); cache `data_id`/`system_name`/`data_filename`/`feature_categories`. With the slug known, these URLs are now constructible with no extra call and count as internal-link inventory targets: the listing `/<data_filename>` (Pattern 2), and the Pattern 3 filter shell `/<data_filename>?…` the draft's own words fill — a date the draft writes → `?daterange` (events), the resolved category → `?category[]`, the geocoded location → `?lat…`; each links when a draft phrase matches it by meaning. Once the content-type file's Post-type discovery confirms the resolved type, write the **category ledger** — one line restating the resolved type and its full category list verbatim (`Post type resolved: data_id=8, data_filename=events, categories: <list>`). Empty `feature_categories` → write `categories: (none)` and omit `post_category` and `category[]` for the whole run; location/date filters still apply. Every later category value — Stage 4 routing, `post_category`, Pattern 3 `category[]` — is copied character-for-character from this ledger line — the ledger is the only category source; any tool response, post row, or memory that disagrees is wrong.
4. **Menu link inventory — one call:** `listMenuItems limit=100 property=["is_default","master_id"] property_value=["false","0"] property_operator=["eq","eq"]` (send `property_value` entries as strings; follow `next_page` while present) — returns only the site's own customized top-level menu items (`master_id=0` keeps the parent links, dropping child items). Bank `{menu_name → menu_link}` into the internal-link inventory as menu candidates; skip rows whose `menu_link` contains `%%%`. Zero rows → proceed without menu links.

Cached data feeds Stage 4 category routing and the internal-link inventory — built across these steps, spent onto the draft at Stage 5's linking pass, the run's link candidates, all first-class: the menu links; live posts dedup returned (Pattern 1); the post type's own listing (Pattern 2); its category, location (from the post's geocoded lat/lng), and — for events — date filters (Pattern 3); the filtered member directory — members by category and/or location, e.g. "acupuncturists in Denver" (Pattern 6); specific member profiles (Pattern 4); and the directory landing (Pattern 5). Pattern 6 and Pattern 4 hold only their resolved ingredients, never an assembled URL, until their gate clears.

Infer location from `primary_country`, vertical from site info and categories. A `Topic/nuance:` line in the run's instructions carrying only style/format constraints is not a missing topic: apply the constraints and choose subjects per the content-type runbook. A `Topic/nuance:` naming the site's own brand or domain — matched against `getSiteInfo`'s `website_name` or `full_url` — is the site introducing itself, not a topic to research: choose subjects from the vertical the same way; the site's own name and domain never enter a search query or fetch.

**Member-city targeting — NEVER bulk-list members to discover their cities.** Only fires when the user's prompt explicitly targets by member coverage ("cities where I have members," "places members are based," "areas we cover"). Use `listCities` — BD auto-seeds it on every member signup, so it surfaces exactly the cities where members exist. Lean response (`city_ln`, `city_filename`, `state_sn`, `country_sn`).

### Author resolution (universal pattern)

Resolve the `user_id` that authors the post. This ladder is the whole resolution — an empty step falls to the next; never sweep members by profession or category to find an author.

1. **User pre-specified** `user_id` **(or** `author_id`**) in the request →** use it, SKIP discovery entirely.
2. **No pre-specified author →** copy the editorial pattern already on the site. Read the most recent post of this type and reuse its `user_id`:
  ```
    listSingleImagePosts property=data_id property_value=<resolved data_id> property_operator=eq order_column=revision_timestamp order_type=desc limit=1
  ```
    Use the returned row's `user_id`.
3. **Fallback A** (zero existing posts of this type on the site) → find a member whose subscription plan is authorized to publish this post type:
  1. `listMembershipPlans limit=25` — lean default returns `subscription_id`, `subscription_name`, `data_settings`, and 7 other identity/pricing fields. `data_settings` is a CSV of post-type IDs the plan can publish (e.g. `"4,2,1,15,8,10,0"`).
  2. Client-side filter: keep plans where `data_settings.split(',').includes(<resolved data_id>)` — these are the subscription_ids authorized to publish this post type.
  3. `listUsers property=subscription_id property_value=<comma_separated_matched_ids> property_operator=in order_column=user_id order_type=asc limit=1` — returns the lowest-user_id eligible author (oldest member with permission). Server-side filter + sort; lean response.
4. **Fallback B** (zero matched plans OR zero eligible users) → use `user_id=0`.



### Post-type disambiguation (universal pattern)

Multiple candidates from post-type discovery resolve in order — never exit over ambiguity:

1. The run's instructions pre-specify a post-type id → use it.
2. The run's wording names a flavor (e.g. "open house events", "internship listings") → single confident `data_name` match wins.
3. The site's editorial pattern — one batched call: `listSingleImagePosts property=data_id property_value=<candidate id CSV> property_operator=in order_column=revision_timestamp order_type=desc limit=1`. The newest returned row's `data_id` wins; cache the row — Author resolution step 2 reuses it. No rows → step 4.
4. No candidate has any posts → the lowest `data_id` (the site's oldest such type).



### Candidate pool discipline (universal pattern)

When the run holds one or more candidates — brainstormed or harvested (topics, events, jobs) — they ARE the pool, together: every candidate the round exposed enters the same printed list, each line `N.` + its title and dedup keys (the content-type file names them); a lone find still prints as `1.` — and it runs every pool stage, Stage 2 dedup included. Emit the full numbered 1-N pool as a visible list before researching any single candidate in depth. A WebSearch or WebFetch aimed at a specific find's domain, venue, or pages — pooled or not — or chosen because of it, is research on that find, not discovery; it waits for the find's `no match - survives` verdict. The pool prints and its calls fire in one message: Stage 2 dedup for every entry — the content-type file names the dedup keys. After the verdicts, take the top survivor; on failure drop it and take the next surviving un-tried — its verification fetches ride the very next message, all together. Do NOT regenerate until all are tried. If all fail, generate pool 2 — distinctly different from pool 1, no variations; a new pool re-enters at the pool print: it prints and fires Stage 2's calls in that same message. If pool 2 also fully fails, exit with the Stage 7 receipt (`shortfall_reason` says why).

**Failure** = dedup hit, source-research can't substantiate, required-field gate misses, or any other condition that blocks the candidate from progressing to post creation.

Pool size — harvested pools: every qualifying candidate the round's results expose (WebSearch results and opened list-pages), up to 10. Brainstormed pools (generated topics): the runbook's stated `N`. Both in the order found.

## Stage 2: Duplicate detection

Run all pool candidates together, in ONE turn — the same turn the pool prints. A candidate at any later point without its verdict line → run Stage 2 now for every verdict-less candidate, before their next call. A dupe drops for the cost of one dedup round, not a wasted research cycle. Never bulk-list a site's existing posts. Bank every live (`post_status=1`) row this stage returns into the internal-link inventory as a Pattern 1 candidate (`/<post_filename>`), non-duplicates included.

With the pool printed per `Candidate pool discipline (universal pattern)`, one compound query (**Rule: Compound filters**) covers the titles; the content-type file adds any further retrieval keys as their own separate calls, batched in this same turn. `property_value` is exactly TWO elements — never one, never one per candidate — element 1: ALL candidates' variants (each 1-3 words — trim full names to their distinctive core) comma-joined into ONE string — 3 × N values, one string; element 2: the data_id alone:

```
listSingleImagePosts property=["post_title","data_id"] property_operator=["contains","eq"] property_value=["Campbell River,River Marathon,Campbell Marathon,Studio Three,Reformer Week,Pilates Reformer","<data_id>"] limit=50 fields_only="<the content-type file's Dedup fields_only list>"
```

Two candidates, three variants each — a one-candidate pool runs its three alone; a ten-candidate pool, the same call with thirty variants in element 1. A compound that errors re-fires once, corrected, still covering every candidate — never re-fired per candidate.

Substitute the `list*` tool matching the post-type family. Compare returned rows client-side against the content-type file's match criteria; the message after the dedup calls opens with one verdict line per candidate — the matched post_ids `- dropped`, or `no match - survives` — each verdict citing the keys probed (the content-type file names them).

**Distinctive phrase = a 1-3 word combo that fingerprints THIS candidate.** Skip throwaway leaders — articles (`The`), years (`2026`), ordinals (`5th`, `Annual`, `Inaugural`): `"The 5th Annual Austin Tech Summit"` → `Austin Tech,Tech Summit,Austin Summit`. A generic single word (`Trainer`) floods the result set; a distinctive combo keeps it lean. Variant shapes — sponsor-stripped form, series or venue fragment; shorter substrings match more retitlings. Variants are free; a retitled dupe only matches a variant.

The content-type file specifies match criteria (semantic title overlap, date tolerance if applicable, location if applicable).

**On match → drop candidate per** `Candidate pool discipline (universal pattern)`**.** Don't repaint with a tweaked title or "refined angle" — same core topic = same candidate. Drop it. Never bulk-list or probe existing posts to find a gap. Never ask the user for a replacement topic.

Always SKIP existing records — never update or delete any existing post.

## Stage 3: Source research

**2a.** Brainstorm 5-10 candidate source types for vertical+location per the content-type file — vocabulary for judging what returns, never for composing queries; query shapes come only from the discovery ladder and the content-type file's commanded searches.

**2b.** One batched round per **Rule: Search discipline** — the discovery ladder's single turn of five queries. Read every result — reading triggers the pool print, not new queries; a `site:` query (with `-pdf`) may target only a domain that appeared in an earlier round's results. Drop dead/empty/archive pages.

**2c.** Survivors only — the verdicts' own message carries these calls: `WebFetch` the top survivor for each remaining post in the goal — every survivor's page fetch and any second-source search share ONE message, packed to at least five per `Rule: Search discipline`; a follow-up message carries only fetches of URLs the first surfaced, the `URL liveness gate`'s one confirm search when a fetch blocked, and the commanded re-probe when a date, venue, or city changed — nothing else until verification completes — and packed the same, at least five while the classes supply them. 2c's score: how many of verification's calls share the one message — every extra turn spends tokens and time. WebFetch returns LLM-summarized markdown, NOT raw HTML — if you need specific `<head>` content (OG meta tags, JSON-LD), name them in your prompt explicitly ("extract og:title, JSON-LD schema.org Event"). Every extracted record must pass all 6 gates:


| Gate               | Rule                                                                                                                                                                                                                                                                                                                                                             |
| ------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Date sanity        | Primary date must be present AND > today AND < today+window. Window defaults to 90 days unless the user specifies otherwise (via `--window=<N>` or in their request). Absent/past/year-only/quarter-only fails — drop the candidate, never synthesize a date to pass this gate.                                                                                  |
| SPA / empty        | <500 chars of meaningful text OR script-shell page → skip.                                                                                                                                                                                                                                                                                                       |
| Required fields    | The content-type file specifies. Missing any → skip. No synthesis.                                                                                                                                                                                                                                                                                               |
| Confidence         | Self-rate 1-10. Score = how unambiguous and source-grounded the required fields are. <8 skip, ≥8 use.                                                                                                                                                                                                                                                    |
| Source credibility | Gov/association/university/established trade or broader-vertical publication = high (1 source OK). High only if its URL resolves to the claimed organization; same-owner outlets = one source. SEO farms, lead-gen sites, practitioner blogs, authoritative-sounding names without a verifiable charter = fail. Random blog/aggregator = low (needs 2-source confirmation). This gate judges returned pages — nothing in it becomes a query term or `site:` target; query shapes come only from the discovery ladder and the content-type file's commanded searches. |
| URL liveness       | Every external URL the post links to must be verified before publish per `URL liveness gate`.                                                                                                                                                                                                                                                                             |


**2d.** Cross-reference: 2 sources confirm → merge details, boost confidence.

**2e.** Stop at ~10-20 verified records or no new candidates.

### URL liveness gate

Every external URL the post will link to — each exact path, a verified domain never clears its other paths — must be verified live before publish (internal URLs verify per their Pattern's own gate). Three outcomes by `WebFetch` response:

- **HTTP 200 with real body content** → use. (200 with "page not found" / "error" body text is a soft-404 — treat as dead.)
- **404 / DNS fail** → drop the link, or skip the record entirely if it's the primary action URL.
- **403 / 401 / 429 / timeout / WAF block** → **UNKNOWN, not verified.** A CDN is blocking the bot UA, not proof the page is dead. Never ship on the rationalization that it's "probably live." Confirm the exact URL string in the results of at most ONE search — riding its message's pack per **Rule: Search discipline**; still unverified → drop.

**Third-party-sourced URLs** (aggregator, secondary listing) always require independent verification — never trust the third party's link as-is. Apply the `URL liveness gate` three-outcome decision tree.

## Stage 4: Category routing

Fuzzy-match source category vs the **category ledger** list. ≥70% confidence → carry the LEDGER value forward, never the source's wording. <70% → SKIP the record (do NOT create categories). Bank the resolved category into the internal-link inventory as a Pattern 3 filter candidate, and as a Pattern 6 member-directory ingredient marked "pending gate" — the member-count gate in the pre-create batch assembles and verifies it (count >= 1 to link, per URL-PATTERNS).

The content-type file may specify a fallback category.

## Stage 5: Content manufacture (universal)

**Goal:** an EEAT-rich landing page that is THE definitive source for its subject — external sources exist to support this page's claims, never the other way around; the page never mentions or evaluates another page. Real internal-linking, structured info, honest source-grounded facts. No prescriptive template — design structure to fit THIS record. A music festival, a CME workshop, an open-house, and a software-engineer job listing all look different.

### Required outcomes (any structure achieves these)

A good post covers the full picture: core facts, practical considerations, useful context, deeper facts on the location/category/focus where the source or confident knowledge supports them. Read like a knowledgeable friend, not a press release. Bulleted lists where scannability helps; vary paragraph rhythm; section length scales to source depth (expanded when source data + confident knowledge support more, tighter only when both are genuinely exhausted).

1. **Load-bearing facts up front.** The first intro paragraph answers the core question for THIS post type ("what is it, when/where, how do I get it / attend / apply / use it") across its sentences, never packed into one — and the body never opens with the post title restated. The content-type file names the load-bearing facts for the data type.
2. **Every record fact source-supported — by a source about THIS record.** A similarly-named different event, role, or record is a different subject, never a source. No fabrication. Adaptive depth based on what source data + confident AI knowledge support. Source-supported depth beats both padding and stubs — short because you skipped multi-angle context, comparison, useful perspective, or related information the source data supports is a failure; short is fine only when source and confident knowledge are both genuinely exhausted.
3. **External source citations: 2 per ~500 words, cap 4 total (a ~500-word listing carries 2-3; a ~1,000-word-plus post 4)** (fewer only when credible sources are genuinely exhausted; for article-type posts one per source — same-owner pages = one source; a listing's externals may all be the record's own pages — each page once, the CTA button's URL excepted — that one is the button's alone, never also a citation — each backing different record facts — the page itself never a sentence's subject or a section's topic; per the Source credibility gate), never before an internal link per `Link order`. Source in order, stopping at target: (a) this run's Stage 3 verified set — zero calls, the default path; (b) one batched round per **Rule: Search discipline**: broad topic query (3-6 plain words, no operators) + a `<topic> guidelines`-or-`standards` companion, judged by the Source credibility gate, then one `site:` probe on a surfaced domain — it rides the citations' fetch pack; (c) practice/profession topic → its encyclopedia article's institutional references; (d) ship with fewer — legitimate only once (b)'s round has fired. Budget: 3 WebSearch + 2 WebFetch per post. Cite static destinations only — a specific article, abstract, or the organization's own page, never a search-results/query URL (`?term=`, `?q=`, `search?`, tag/archive indexes), never a login-gated page. A citation wraps a short 2-to-5-word phrase the finished draft already contains — never a whole clause or sentence — in a sentence about the subject — never the post's first sentence, never a sentence about the source, never a sentence added to carry it — with `rel="noopener" target="_blank"`; no forced "Source: X" footer. Helps Google EEAT (Experience, Expertise, Authoritativeness, Trustworthiness) signals.
4. **Internal links riding the draft's own phrases** — use any URL-PATTERNS.md pattern the draft's phrases support: Pattern 1 (specific post URLs), Pattern 2 (the post-type listing), Pattern 3 (that listing filtered by category, location, date, or combos), Pattern 4 (a member's profile), Pattern 5 (the directory landing), Pattern 6 (the member directory filtered by category and/or location). **After the body is fully written and before the create call, run the linking pass as an explicit step — never skip it.** The internal-link inventory is already in front of you — the running list reprinted each message (Pattern 6 and Pattern 4 candidates are ingredients marked "pending gate", their URL assembled only after the member-count gate passes). Take each inventory item in turn and scan the finished draft for the single best phrase that matches it by meaning; on a match, wrap that one phrase in the link in place, then move to the next inventory item. The inventory informs link placement only, never which facts the body covers — the body is already written; this pass adds links, nothing else. Each inventory URL is placed at most once — a second draft phrase that matches an already-placed URL stays unlinked (no href twice, no anchor phrase twice). An inventory item with no matching phrase is left unplaced, never forced. Different inventory items still each take their own link, so the finished post carries several distinct internal links, not one repeated. One inventory item always has a matching phrase and is placed every run: the post's own resolved category filter (Pattern 3, the single category this post is filed under — never a different category whose words happen to appear). Its anchor is fixed, not searched-for: take the post's main topic — the 2-to-5-word subject phrase from its own title (the sprint-training post → "sprint training"; the senior-yoga post → "senior yoga") — wrap its first mid-sentence occurrence in the body — never an occurrence that opens a sentence; only if the phrase never appears mid-sentence, wrap the first and capitalize its first letter. "No phrase matched" is never the verdict for this one. The anchor never names the site or its listings ("training tips articles", "our blog"). The post-type listing (Pattern 2) is never force-placed, and never hosted by a sentence about the site's own articles. A link anchor is any 2-to-5-word phrase the draft wrote that matches a target by meaning — the same subject or concept, shared words not required ("weightlifting" matches a "Strength Training" target); the draft's own phrasing rides the anchor, the ledger label rides the URL only, and taxonomy words ("category", "section", "archive") never enter the prose. A Pattern 6 slug uses only the location segments whose place noun the draft wrote and the category segment its subject noun, built per **Link shape priority**. **The internal-link score: how many internal links the final post carries — 5 per 500 words is full marks — minus one for each duplicate href, each duplicate anchor phrase, and each anchor that opens a sentence, floored at 0; the richer post of distinct qualifying links wins. An anchor qualifies only when its sentence reads identically with the link removed — the phrase already earns its place in the prose for the fact it states, and the link merely wraps it; a phrase the draft does not already hold is not created to be linked.** Density: no href twice, no anchor phrase twice, distributed throughout the post and across the Pattern types the draft's phrases support, never clustered. The linking pass may not add, reshape, or reorder a single sentence. Pattern 1/2/3/5 links are in hand — valid by construction or already-live — and are placed, no check, on every qualifying anchor the draft already holds; an inventory target with no qualifying anchor goes unlinked, never hosted by a sentence written or bent to carry it. Pattern 6 and Pattern 4 candidates are ingredients only: run their member-count gate (per URL-PATTERNS) all together in ONE message; each pass promotes its candidate to a placed link, each fail drops it to a Pattern 3 URL in any filter shape, or Pattern 5.** **A sentence, bullet, or clause that exists for a link is a worse failure than an unlinked phrase; wrapping a phrase a sentence already owns is never the crime; no ceiling and no density limit outranks the prose, and no link is placed by inventing or angling a sentence to host it.** Anchor text reads as part of its sentence — a sentence about the topic, never about the linked destination — never a standalone CTA, never a trailing "More X in Y" section. Never fabricate URLs; a reference with no verifiable target omits that link.
5. **External links to sources, ticket/registration vendors, organizers' own pages** — with `rel="noopener" target="_blank"`.
6. **Work through every depth dimension that fits the post type** — their material is the subject and its real world, never the site's own posts or pages. Each developed dimension is its own `<h2>` section — more supported dimensions, more sections, a fuller post; skipping a supported dimension is the failure, omit only one that would require guessing. A section's heading rises from THIS record's own material and names its participants — a dimension's label ("Setting", "Overview") never enters a heading or the prose. The depth score: how many dimensions the record's facts and its subject's confident knowledge develop — the fuller post wins.

  **Dimension ideas — draw from these, not limited to them:**
  - **Observable specifics** — the record's own, stated as settled knowledge.
  - **Audience fit** — skill level, accessibility, life stage — for whom.
  - **Practical considerations** — first-time/day-of detail rarely on the source page: prerequisites, logistics, exclusions, hidden costs, timing — pitfalls as if/then facts ("If X happens, Y is the fix").
  - **Historical / community context** — provenance, longevity, lineage, reputation.
  - **Local context** — neighborhood character, nearby landmarks and amenities, parking, transit/access. Skip when the post type has no place anchor.
  - **The organizer and venue's story** — who runs it, their history, what they're known for; confident knowledge counts ("open since 1937 in the same Fifth Street building").
  - **Industry insight / players** — real peers and market leaders from the wider market, named with their facts.
  - **Standout fact** — a verifiable fact that sets the record apart in its real market ("the city's only weekday-morning session"). Never puffery, never praise of the post or its source.
  - **The program / agenda** — the published run of show: day-by-day or hour-by-hour flow, itinerary, speakers or session lineup; a start time alone is logistics, a flow is a section.



### Froala HTML safety

Follow **Rule: Post-body formatting** and **Rule: No scaffolding tags**. Skip `<h1>` — reserved for the post title field. **Always open** `post_content` **with** `<p>` **intro paragraph(s); never start with** `<h2>` **or any heading.** `post_content` is public-facing only — never include HTML comments, source notes, machine-readable metadata, or skill-run identifiers.

### Link policy (strict)

Classify every `<a>` tag by host comparison against `getSiteInfo.full_url`. Relative URLs (start with `/`) are always internal.


| Type     | Format                                                                                |
| -------- | ------------------------------------------------------------------------------------- |
| Internal | `<a href="/..." title="<descriptive>">text</a>` (no rel, no target)                   |
| External | `<a href="https://..." title="<descriptive>" rel="noopener" target="_blank">text</a>` |


Full `title=` requirement + composition examples in URL-PATTERNS.

### Link order (universal)

1. **Internal and external links carry separate budgets — neither draws from the other.** No two externals in the same or consecutive sentences.
2. **Unique href per post.** No URL repeats — the CTA's URL counts. If two anchors would target the same URL, re-derive one under a different Pattern (1-6); drop only if no Pattern variant fits.

### Image strategy

Use Pexels for all images. After both axis batches yield no commit, omit `post_image`. Omitting is the last resort.

Every run works the axes fresh in the table-defined order, batch by batch until a commit — stock-photo inventories change daily.

**If** `poolImages` **is not in your tool list, ignore this paragraph and run Steps 1-3.** With the tool, `poolImages` replaces Steps 1-3: call it once per batch — `axis_terms` = the batch's five axis phrases (batch 1 = axes 1-5, batch 2 = axes 6-10 from the **Axes** table), `shape="landscape"`. In a runbook step that batches calls, `poolImages` is born to fire alongside the other tools' calls — it rides that step's batch message. It returns a numbered shortlist `{n, title, desc, url}`, already orientation-filtered and site-deduped. Pick the `n` whose title and desc best fit and put that `url` in the post's create call per **Rule: Image URLs** with `auto_image_import=1`. The image is then settled — do NOT re-check it: no `getImageDimensions` and no `listSingleImagePosts` dedup on a `poolImages` url. No title fits, or an empty result → call `poolImages` again with the next axis batch; both spent → omit `post_image`.

**Pexels** — follow **Rule: Image URLs** exactly. Always send to BD with `auto_image_import=1`.

   **Axes — 10 in order. Batch 1 = WebSearch each of axes 1-5 (five searches, one turn); batch 2 = axes 6-10 if batch 1 yields no commit. Each search returns that axis's raw results.**

   Each search phrase must carry a topical anchor — a vertical-specific word that ties the photo to the topic.


| Axis                                 | Why                                                             | Cafe blog: "choosing an espresso machine"             | Web design blog: "button color trends"             |
| ------------------------------------ | --------------------------------------------------------------- | ----------------------------------------------------- | -------------------------------------------------- |
| 1. Subject + state (default)         | The thing in its defining state                                 | `barista pouring` / `barista pouring coffee`          | `colorful buttons` / `modern ui buttons`           |
| 2. People + adjacent action          | Same audience, related verb                                     | `barista cleaning` / `barista weighing beans`         | `designer sketching` / `designer choosing colors`  |
| 3. Detail / object close-up          | A topical **prop or equipment** shot, no people                 | `portafilter shot` / `espresso shot pour`             | `button mockup` / `colorful interface element`     |
| 4. Setting + topical marker          | Topical location, named                                         | `coffee shop` / `coffee shop bar`                     | `design studio` / `ui designer desk`               |
| 5. Adjacent activity / item          | Related thing, different action                                 | `latte art` / `coffee bean grinder`                   | `color swatch` / `figma wireframe sketch`          |
| 6. Result / outcome                  | The finished artifact, static, no process                       | `latte cup` / `finished espresso drink`               | `finished website` / `launched landing page`       |
| 7. Process step / intermediate stage | A pre- or transitional workflow moment, not the headline action | `coffee beans roasting` / `tamping grounds`           | `wireframe sketches` / `mood board layout`         |
| 8. Materials / raw inputs            | Ingredients or textures before they become the subject          | `coffee beans` / `roasted coffee`                     | `color palette` / `font samples`                   |
| 9. Customer / recipient POV          | The consumer side, not the practitioner                         | `customer drinking coffee` / `person ordering coffee` | `user browsing phone` / `person reading website`   |
| 10. Hands / body-part isolation      | Symbolic close-up, hands as stand-in, no faces                  | `hands holding cup` / `hands pouring coffee`          | `hands typing keyboard` / `hands sketching design` |


   **Comparison-shape posts ("X vs Y"):** Axes 3-10 must cover BOTH halves of the comparison, not just the primary subject. For "espresso vs pour-over" the prop axis needs items from both methods; for "React vs Vue" the setting axis needs developers using both stacks.

   **One search per axis.** Each axis gets exactly one search phrase — do not retry an axis with reworded phrasing (that drift, "let me try axis 2 with one more phrase," is the most common axis-discipline failure).

   **Batched-axes loop.** A batch runs Step 1 through Step 3 in order: fire its five Step 1 searches in ONE turn as parallel calls, then run Steps 2 and 3 once over all five searches' combined results, every result from all five, not one per search. Batch empty of a commit → next batch. Both batches exhausted → omit.

   **Step 1 — Search construction.** `WebSearch query="site:pexels.com/photo <axis phrase>"` per axis, using each axis's phrase from the **Axes** table. NOT `site:pexels.com/search` (403 on agent runtime). NOT `wide`/`landscape`/`horizontal` (Pexels indexes those as title/tag terms, not orientation). **2-3 words. Every word must carry topic information** — no filler ("the", "a"), no redundant adjectives, no contradictions. 2 words when the noun is already specific (`"pilates reformer"` — "reformer" disambiguates); 3 words when the noun is ambiguous (`"pasta plate restaurant"` — bare "pasta plate" returns dishware). 1 word is banned (pure noise pool).

- Cross-vertical examples: ✓ `"fitness race competition"` (3, events/sport), ✓ `"professional conference audience"` (3, events/corporate), ✓ `"pilates reformer"` (2, blog/fitness — already specific), ✗ `"beautiful red pasta"` ("beautiful" is filler), ✗ `"plate"` (banned).
- **Cross-axis duplicate guard.** Keep each `/photo/<id>/` once — a duplicate another axis already surfaced collapses to a single entry.

   **Step 2 — Dimension-check the whole pool.** Take every `/photo/<slug>-<id>/` result from all searches, build each canonical URL `https://images.pexels.com/photos/<id>/pexels-photo-<id>.jpeg`, and pass them ALL into ONE `getImageDimensions urls=<URL1,URL2,...,URLN>` call (up to 50). Omit only clearly off-topic results (wrong vertical — karate for a judo post); every plausibly on-topic result goes in. Read each row of that one response:

- **status=success +** `message.orientation === "landscape"` → landscape survivor, carry to dedup.
- **status=success + portrait OR square** → drop.
- **status=error** (404, timeout, parse fail, "unsupported image format") → drop.
- **Zero landscape survivors → next batch.**

   **Step 3 — Dedup (one batched call via** `in` **CSV).** Take every Step 2 landscape survivor as one list and run **Rule: Image dedup** — one `list`* call (matching the write tool) with `property=original_image_url`, `property_value=<URL1,URL2,...,URLN>` (up to 50), `property_operator=in`. Response rows include `original_image_url` and `post_title`. From that one response, read the survivors in entry order and commit the first that clears both checks:

- **URL in the response** → that survivor is a URL-dupe; skip it.
- `post_title` **semantic-matches the survivor's topic** → skip it (per `Candidate pool discipline (universal pattern)`).
- **Neither hit** → commit this URL as `post_image`.
- **Every survivor drops → next batch.**
**Both Image strategy batches ran and nothing committed → omit** `post_image`**.**

**Multiple inline body images** (`post_content`, `group_desc`). Long-form posts (blogs especially) often weave 2-5 inline body images alongside the feature image. Each inline image goes through the `Image strategy` sourcing workflow. **Dedup scope:** **Rule: Image dedup** applies to the feature image only. Inline body URLs require intra-post uniqueness — no URL repeats within the post, no body URL equals the feature URL. Inline body images are NOT checked against other posts site-wide.

### Voice

Every `ANTI-SLOP.md` rule is a pass/fail gate the post must clear — a single rule it fails is a failed post.

For listing-type posts (events, jobs), this page IS the record's own page — the record needs no re-introduction: facts carry their own subjects, never a framing-abstraction under a light verb, the record-noun an ordinary subject. State the record's facts as settled knowledge, time, place, or a because-clause free to lead a sentence. Never make a source document — or anything that publishes, displays, or evidences a fact — a sentence's actor, quoting or analyzing — state each fact bare or leave it out — a fact from the fetched source IS the record's fact; bare assertion is the accurate report; two source facts may share a sentence, a because/while/so between them stating both, never inventing — the joint carries fact, never a mood or appeal — attribution is never a third door; a record fact the source omits is silently absent, never reported as a gap. This source-only rule binds record specifics alone; the subject's domain is yours to develop from confident knowledge as expected depth, its own section each, never puffery. The content-type file supplies the record's example set, its record-specifics scope, and its domain dimensions.

### Body shape (universal)

Two intro paragraphs, at least six sentences split unevenly between them (never an even split), state the record's facts in any natural flowing order (the content-type file supplies the fact list and the first-sentence naming rule). Between intro and close, at least four `<h2>` sections, each a fully-developed distinct dimension section, rich in real content — at least two developed paragraphs, never a one-paragraph shell, never padded to reach it, never a section repeating another's facts; at least one pairs its paragraphs with a scannable `<ul>` of its enumerable facts. The post closes with two paragraphs about the record, at least six sentences split unevenly between them (never an even split) — the close advances (the content-type file supplies what it advances to) — never a restatement of the body. Every sentence advances something new — a fact, dimension, or insight not already in the post; a restatement is filler, cut it. Out of new material, end short — never pad; links riding real sentences stand. Section `<h2>`s: record-material noun phrases, never questions, never a dimension's label.

### Action CTA (universal)

Unless the user requests otherwise: when the official URL is known, it is reserved for this CTA. The CTA follows the lead bullets (no `<h2>` above it), in order, neither part skipped: (1) the button `<p><a class="btn btn-secondary btn-lg vmargin" href="<an official URL this run fetched, copied character-for-character from its source>" title="<descriptive phrase>" rel="noopener" target="_blank">Button Text In Title Case</a></p>`, (2) a 2-3 sentence third-person `<p>` on how to act (the steps, what to have ready — never commands, never the button, link, or form described, never what they open). The URL is the button's first — never a body citation; never the button alone; never an action or login-gated path — public pages only. On create, omit `post_url` unless the user requests it — the URL lives in this CTA. The content-type file supplies the act verb (register / apply).

### Bullets (universal)

The record's core facts as one scannable `<ul>` immediately after the two intro paragraphs — before the CTA button, no `<h2>` above it (the content-type file supplies the field list). A slot the source doesn't fill is dropped, never written as missing. A later section whose facts enumerate presents them as its own `<ul>`.

### Section headings (universal)

Record-material noun phrases — the record's own facts, work, program, or specifics; never the site's categories or an assembled search phrase, never forced or stuffed, never a dimension label (the content-type file supplies the banned-label examples per type).

### Depth (universal)

A listing page is a destination, not a stub nor a spec sheet — every sourced fact enters under its dimension as settled knowledge, and confident knowledge fills every dimension the subject supports (the content-type file supplies the dimension and knowledge lists); a fact or a dimension left unused is the failure — record specifics stay source-only, never invented. Each `<h2>` develops material no other section covers: a fact — a venue, a date, a price, a registration path — is stated once in the one section that owns it, never again anywhere: not in another section, not later in the same section, not in a bullet list, not a trailing paragraph. A section whose content is facts already given elsewhere is cut, not written. The last `<h2>` is a dimension too, not a summary — it carries its own facts not surfaced anywhere else, never a wrap-up of the post. Self-praise and superlatives are not facts — they never enter, bare or attributed; the verifiable specifics they decorate enter bare. A known official URL is fetched before drafting, its prompt asking for that cargo alongside the logistics.

### Internal links (universal)

Placed from the internal-link inventory by Stage 5's linking pass, per **URL-PATTERNS `Pattern 3 filter params` and `Pattern 6 — Filtered member directory`** (member-count gate) and **Link shape priority** — no per-section quotas: the density law alone places them, riding only phrases the body writes. The content-type file supplies the filter dimensions available per type.

### Self-check before posting

Scan the assembled body AND the create-call field values. Fix anything that fires:

- Any en/em-dash outside code? Rewrite.
- Internal link with `rel="nofollow"` or `target="_blank"`? Strip those attributes.
- External link not carrying exactly `rel="noopener" target="_blank"`? Fix it.
- Citation on a search/query URL? Replace with the static source page, or drop.
- Any fabricated detail? Remove.
- Each internal link: delete the `<a>` tag and read the bare sentence. It must still state a real fact and read naturally, with no dangling stub ("in this guide to", "this breakdown of", "which is where a", "can start by browsing"). A sentence that fragments without its link was written to carry it — cut the link, and the sentence too if nothing else holds it up.
- Each link left the sentence intact — only `<a>` tags added, not one word dropped or changed. Re-read it: a subjectless or broken clause ("The opened on March 20...") means wrapping the link ate a word — restore it.
- Any sentence bolted on or bent toward naming a related post to host its link ("this also fits X", "which pairs with Y")? Cut the link; keep the sentence only if it makes a point on its own.
- Every link — internal AND external — has a 2-to-5-word anchor. Longer? Shrink it to the subject phrase; the rest stays unlinked text.
- FORBIDDEN: an anchor as the first word of a sentence. Every anchor sits mid-sentence, non-negotiable. One that opens a sentence → move the link to a mid-sentence phrase, or drop it; capitalize the first letter only when no mid-sentence phrase exists (a sentence never opens lowercase).
- Any Pattern 3 filter link (`?category[]=`/`?lat=`/`?daterange=`) based on `/search`? Rebuild on `/<data_filename>?…` (`/blog?…`, `/events?…`) — `/search` takes no filter params.
- Unsourced record fact presented as fact? Hyperlink it to its source or rewrite — naming the source in prose is not sourcing, and a source-naming sentence still rewrites after the link.
- Same href twice, or the same anchor phrase linked twice? Re-derive one under a different Pattern, or cite a different source's static page for an external; if neither the href nor the anchor can be made distinct, drop the second link.
- `post_category` and every Pattern 3 `category[]` value copied character-for-character from the **category ledger** (written at `Stage 1: Site context` step 3)? Re-read that ledger line — do not trust memory. A value not on it filters nothing — fix to the matching ledger category or drop the param. The `post_category` create-field value carries a raw `&`, never `&amp;` — an entity there mis-files the post; the `category[]` value inside an href URL-encodes its literal `&` as `%26` (the query-separator `&` between params is the only `&amp;`).
- Does the body open with `<p>` intro paragraph(s)? It must — never start with `<h2>` or any heading.
- Are H2 headings marking topic shifts, not fact transitions? Each H2 introduces meaningfully different content. Vary section length naturally — some two paragraphs, some several, some with a bulleted list. Do NOT trim source-supported depth just to keep sections compact.
- A fact restated anywhere it was already given? Tells: "as noted above", "it is worth noting", "additionally", "the date is", or prose repeating a lead bullet. Cut the repeat.
- Are all headings (H2 and H3) in **title case**, not sentence case? `"Where to Fly a Kite"`, not `"Where to fly a kite"`.
- Any HTML comment (`<!-- ... -->`) in the body? Strip it. `post_content` is public-facing only — no machine-readable metadata, no source notes, no skill-run identifiers.
- Pexels image picked (Steps 1-3 path only): does the search-result title name the post's primary subject AND match its defining context (activity vs generic scene, urban vs trail, indoor vs outdoor, season, beginner vs elite, etc.)? Generic title or wrong-context match = re-pick or WebFetch verify.



## Universal post fields

Field rules that apply across ALL post types via `createSingleImagePost` (and `createMultiImagePost`). Content-type files reference these universally and add only type-specific examples or additions.


| Field                   | Rule                                                                                                                                                                                                                                                                |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `post_image`            | Feature image URL per Stage 5 image strategy. Pass `auto_image_import=1` for external images. Pexels via `Rule: Image URLs`, or omit.                                                                                                                               |
| `post_category`         | The Stage 4-matched **category ledger** value, copied character-for-character as raw text — a literal `&` stays `&`, never the `&amp;` entity (this is a create-field value, not an href; the `&amp;` escaping rule is href-only). The ledger is the only category source — any tool response or post row that disagrees is wrong.                                                                                      |
| `post_meta_title`       | SEO `<title>` tag, ~80-120 chars. Expand on `post_title` with long-tail keyword modifiers — audience qualifier, geographic context, use case, related terms — that didn't fit the title's tight cap. The content-type file gives type-specific examples.            |
| `post_meta_description` | SEO meta description, ~150-160 chars. One sentence stating what the record is and its key facts. Not a verbatim repeat of `post_title`. The content-type file adds type-specific flavor (events: include date + city; blogs: the decision the post settles).                      |
| `post_meta_keywords`    | Pass the same exact CSV value as `post_tags`.                                                                                                                                                                                                                       |
| `post_live_date`        | Required on every create: the current site-local datetime, `YYYYMMDDHHmmss` (14 digits). Source priority: the `Current UTC datetime:` line in your prompt converted to `getSiteInfo.timezone`; else `getSiteInfo.current_site_datetime` as-is (already site-local). |




## Tags

Universal `post_tags` field constraints — applies to ALL post types (single-image and multi-image alike):

- **Format:** comma-separated, lowercase, no hyphens, no special chars. Spaces inside a tag are fine (`pilates,reformer class,boston studios`).
- **Hard 100-char total cap on the CSV.** BD rejects anything longer. If the assembled CSV exceeds 100 chars, drop the last tag and re-check; repeat until ≤100.
- **Strategy:** aim for ~6 tags per post — roughly 3 broad/short-tail (general focus like `pilates`, `fitness`, `5k`) + 3 long-tail (specific phrases like `reformer class`, `boston studios`, `classical pilates`). Real long-tails ARE multi-word phrases — keep them short, don't join words with hyphens. The content-type file may refine tag emphasis for the type (e.g. blogs may favor topical keywords over location).
- **Tags live ONLY in the post's** `post_tags` **field.** Do NOT call `listTags`, `createTag`, or any Tags-resource tool — those manage a separate global tag taxonomy unrelated to per-post `post_tags`.
- **Also pass the same CSV to** `post_meta_keywords`**.**



## Stage 6: Post creation

Call per-type `create*` tool with assembled fields. Assemble against the per-type field reference: every field this run already resolved ships — copy values (e.g. `lat`/`lon`, `post_location`, `post_venue`) verbatim from the run's earlier tool results, never from memory. Pace BD writes ~600ms apart. On a 5xx failure — or a success response without a `post_id` greater than zero — one exact-title `listSingleImagePosts eq` probe — row present → the post was created and its row's `post_id` stands as the create response's for Stage 7; row absent → retry the create once. Any other failure: continue to the next record. Never retry blindly.

## Stage 7: Closing reply + JSON receipt (the final message, always, in this order)

After the last create's response, the run is not finished until you emit this — never stop on the create tool call. The receipt fires only when no candidate still owes a create — a due create's message is never the receipt's. A run that created posts but sends no receipt still owes one. Each of the goal's slots ends created (a real `post_id` greater than zero — a `posts` entry) or not, for a reason named in `shortfall_reason` (no candidate found, conflicting input, a failed gate, dedup, or a create that returned no live `post_id`).

**Part 1 — the human reply, plain Markdown.** `-` bullets, links as `[text](url)`, zero HTML tags. One parent bullet per post in the receipt's `posts` array — the title linked to its live URL — with one child bullet per detail: post type, post_id, author (name + user_id), publish status (published live / saved as draft), the full live URL written out, the `<admin_edit_url>` linked as "View in Admin". No bullet presents any other post. A count under the goal states the shortfall reason plainly in the reply. Never narrate the process or your own output mechanics ("Emitting the receipt", "Here is the JSON").

**Part 2 — the receipt**, a raw JSON object directly after the reply:

- The receipt starts at `{` and ends at `}` — no markdown fences, no prefix labels, nothing after the closing brace.
- Return complete, valid JSON — never partial or truncated. Pretty-print at every nesting level: 2-space indent, one field per line — including each object inside `posts`, never compacted onto one line.
- ONLY these fields, in this order — never add extra fields: `post_create`, `post_create_goal`, `post_create_count`, `posts`, `shortfall_reason`.
- `post_create`: `1` (this run's task was creating posts). `post_create_goal`: the requested post count — from the run's instructions, never lowered to match the outcome. `post_create_count`: posts with a `post_id` greater than zero returned by a `create*` response this run — nothing else counts.
- `posts`: one object per real `post_id` greater than zero — from the `create*` response, or the Stage 6 confirming probe when the response lacked one — copied verbatim, never predicted from the title or filled from the fields you sent. No real `post_id` = no entry (never a placeholder `0`). `{"post_id": N, "post_type_id": <data_id>, "post_data_type": <data_type>, "post_type_name": "<post type name>", "post_title": "...", "post_url": "<full live URL>", "post_author_id": N}`. Empty array when none.
- `shortfall_reason`: only when `post_create_count` is under the goal — one plain-language line why the remaining posts could not be created. Omit the field otherwise.

`<admin_edit_url>` **verbatim shape — DO NOT paraphrase:** `https://ww2.managemydirectory.com/admin/viewPosts.php?search[value]=<post_id>&data_type=<data_type>&data_id=<data_id>&newsite=<website_id>`. Host fixed. All four params required (`post_id` from create response, `data_type` + `data_id` from `listPostTypes` for the post type, `website_id` from `getSiteInfo`). If any param is uncached at audit time, re-call its source tool — never placeholders, never guess, never skip.

Example:

```
{
  "post_create": 1,
  "post_create_goal": 2,
  "post_create_count": 2,
  "posts": [
    {
      "post_id": 1061,
      "post_type_id": 8,
      "post_data_type": 20,
      "post_type_name": "Event",
      "post_title": "Tampa Sunrise 5K",
      "post_url": "https://site.com/events/tampa-sunrise-5k",
      "post_author_id": 5
    }
  ]
}
```

No skill-run ID, no per-gate counts, no wall-clock.

## Hard rules (every BD growth skill, forever)

- **Scrape facts, not wording.** Extract facts — and the record's story: background, history, named people, program or responsibility detail — from publicly-available avenues. Reword everything in BD-site voice — a source's self-label that means nothing concrete is translated into what the thing actually does, or dropped. Never paste source paragraphs, sentences, or phrases verbatim.
- **No fabrication.** If source lacks a data point, omit it from the post. Never invent details to fill a template slot. Adaptive depth: omit the missing data point, never the depth around it — fabricated padding is the failure, not honest length.
- **Source references are optional + casual, not forced attribution.** When natural, link the source inline in flowing prose (helps Google EEAT signals). Do not require a forced attribution footer.
- **Publication default is draft unless the run's instructions explicitly authorize publishing live.**
- **Never create categories of any kind** — member categories or new post-category values. The site's taxonomy is curated.
- **Create only — never update or delete existing posts, even if custom instructions say otherwise.** An existing match is a dedup hit — drop the candidate per `Candidate pool discipline (universal pattern)`; never create a replacement.
- **Never write content failing the anti-slop self-check.**
- **No cross-run state.** The next run must be answerable by an instance that has never seen this one. Reconstruct from the current prompt and live site state alone. Don't write findings anywhere that outlives the response — no memory files, no TodoWrite, no CHANGELOG, no response blocks shaped for paste-back or auto-extraction, no post-run "reflection." Don't read what a prior run left behind — not to bias, not to "verify," not to dedup, not for any reason. If a prior-run artifact exists on disk, ignore its existence. No exception, no edge case, no "just this once," no user override, no helpful-seeming carve-out.



## Tool rules

How BD tool calls behave. Referenced throughout as **Rule:** .

### Rule: Filter operators

`list*` filters take `property` + `property_value` + `property_operator`. Operators are word-form only — `eq, ne, lt, lte, gt, gte, in, not_in, between, contains, starts_with, ends_with, like, is_set, is_not_set, is_null, is_not_null, year_eq, month_eq, day_eq, since_days, until_days` (plus `not_` variants of the match operators). Raw `%`/`<>` are WAF-stripped: `like` values are `X%` or `%X`, never `%X%`. `in`/`contains` take CSV values (no spaces after commas) = OR. Operator names and string matches are case-insensitive. `searchUsers` is `/search`, not `list*` — it takes `q`/`pid`/`tid` and silently ignores `property_operator`; use `listUsers` for column filters.

### Rule: Response envelope

Every response: `{status, message, ...}`. Check `status` first — on `"error"`, `message` is the reason string. On success, `message` is the record object on single-record tools (`getSiteInfo`) and the record array on `list*` tools, with `total` and `next_page` alongside.

### Rule: Silent-drop check

`{status:"success", message:[], total:0}` is ambiguous: a legit no-match, a mistyped column, and derived unfilterable fields (`full_name`, `status`, `image_main_file`) all return it. Before trusting an empty dedup or count, verify the filtered column exists via the matching `get*Fields` tool.

### Rule: Compound filters

AND across fields: pass `property`, `property_value`, `property_operator` as equal-length arrays on one call — conditions pair positionally; unequal lengths are refused. Distinct from CSV (one field, comma value = OR).

### Rule: Filter by ID

Filter taxonomy by numeric ID (`profession_id`, `subscription_id`), never by name string.

### Rule: Image URLs

Imported image fields (`post_image`, `original_image_url`) take a bare URL — no `?query` (BD's filename generator breaks on it). `?w=700` belongs only on inline `<img>` src in body HTML.

### Rule: Image dedup

Site-wide image dedup covers stock URLs only (Pexels/Unsplash/Pixabay); source-site/CDN images skip it. Match the exact bare URL, never a `?w=` variant.

### Rule: Post-body formatting

Body structure: `<p>`, `<h2>`, `<h3>`, `<ul>`, `<ol>`, plus `<a>` links and floated `<img>`. Open with `<p>`; never `<h1>` (reserved for the title). Inline image classes: `fr-dib fr-fil img-rounded` (left) or `fr-dib fr-fir img-rounded` (right) + `style="width: 350px;"`; inline body images landscape only.

### Rule: No scaffolding tags

Never emit `<![CDATA[`, `<invoke`, `<function_calls>`, or entity-escaped HTML into any content field — they render as literal text.

### Rule: Pagination

Pass the returned `page` cursor verbatim — never construct one. `total` is a string; coerce before comparing.

### Rule: Search discipline

A search round fires its five queries in one turn; the pool-print turn carries its calls in one message; after the verdicts a turn carries its steps' specified calls and nothing else — the verification, citation, and liveness research those steps command still fires; improvised WebSearch or WebFetch does not. Web calls travel in packs — a message carrying WebSearch or WebFetch carries at least five: searches, fetches, or a mix, the step's commanded calls first, the spare slots preloaded with the step's own upcoming calls — the next survivor's page, a second source, the citation ladder's next rung — insurance preloaded now is cheaper than a turn spent later; fewer than five only when the step's classes run out — a query echoing a fetched page's content is never a class; a lone genuine call fires alone. The `Geocode ladder`'s tiers are exempt — they ride the pre-create step's ONE message beside its `poolImages` call and title check. A message mixes tools freely — BD calls, `poolImages`, and web calls together; spare slots fill with a later step's specified calls whose inputs are ready. A step that states its own call arithmetic — the pool-print turn's stated count, the create alone — fires exactly that arithmetic. A candidate has later-step calls only after its `no match - survives` verdict; never a pre-verdict WebSearch or WebFetch on — or because of — a find, pooled or not. A step specifying more than ten calls fires them all in its one turn — never split a step's calls. Steps with stated timing (Stage 2 dedup in the pool-print turn) fire at their stated time. Read EVERY result before any new query — qualifying sources routinely rank 5-8. `site:` follows only a full domain a result list surfaced — never a bare TLD or wildcard (`Image strategy` pexels queries and the content-type file's commanded search shapes exempt). Negatives strip a known noise class — `-pdf` on probes, one megaboard domain on jobs queries; more trip bot-blocks; a blocked or emptied negated query retries once without them, riding the next pack. A snippet already showing the dedup keys is a hit unopened — it pools and probes as-is; opening waits until it survives. A round that returns usable results — on-topic, in-market, showing the content-type's dedup keys — has succeeded; every one of them pools, few or many; select from the pool and proceed. Classify only a round that surfaced no usable candidate: error/challenge pages = tooling-blocked → one structurally different five-query retry, then stop labelled "blocked"; clean-but-empty = dry. Ending with less than the target is a successful outcome — report it via `shortfall_reason`. No survivor from a round → the next round uses new angles, never repeats of spent queries. A runbook step's lettered parts are ONE step, all their calls in that step's one message.

**Discovery ladder** (events, jobs, any current inventory): (1) one batched round — a single turn of five queries: the broad-faceted temporal (`<niche> <location> <window>`) + list-page vocabulary (`<location> <niche> calendar/board/listings`) shapes, filled out with extra variants for coverage → read every result — every entry showing the content-type's dedup keys pools NOW: print the pool and fire Stage 2 dedup in bulk in that same message — then proceed; (2) no survivor → another single turn of five new-angle queries, repeated; (3) a swept-dry market → stop with the diagnosed verdict.

### Edge guards

- Enum fields take only values present in live `choices`; `post_category` is NOT one of them — its only source is the **category ledger**.
- Stock images are Pexels-only — never wikimedia, picsum, placekitten.
- Source-page images (events/jobs) are allowed and skip dedup.
- Never carry scraped source text verbatim into `post_content` — reword everything.

