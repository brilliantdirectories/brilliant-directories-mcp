# Event Publishing Routine

Connect to my Brilliant Directories site MCP and run the `bd-skill-content` skill to autonomously create event posts.

Create exactly:

- COUNT: `1` event post
- PUBLISH STATUS: `post_status=1`
- AUTHOR: `user_id=1`

Pick events that fit the niche, carry strong local search value, and whose subject matter naturally connects to related events, locations, and local pros a sentence can link to.

Prefer events with strong local search intent, official source information available, and geographically relevant supporting content.

If a registration or official information URL is known, include this CTA immediately after the intro paragraphs:

class="btn btn-secondary btn-lg vmargin"
